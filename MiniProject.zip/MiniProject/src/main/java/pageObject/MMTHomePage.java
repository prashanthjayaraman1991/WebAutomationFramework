package pageObject;



import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MMTHomePage {
	
	public WebDriver driver;
	public MMTHomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement loginLink() {
		return login;
	}
	
	public WebElement getPassword() {
		return passWord;
	}
	
	public WebElement getUsername() {
		return userName;
	}
	
	public WebElement getLogin() {
		return loginButton;
	}
	
	public WebElement getContinue() {
		return continueButton;
	}
	
	public WebElement getFromCity() {
		return fromCity;
	}
	
	public WebElement getToCity() {
		return toCity;
	}
	
	public WebElement getDepatureDate() {
		return depatureDate;
	}
	

	
	
	@FindBy(xpath = "//p[contains(text(),'Login or Create Account')]")
	WebElement login;
	
	@FindBy(id ="fromCity")
	WebElement fromCity;
	
	@FindBy(id = "toCity")
	WebElement toCity;
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox dates inactiveWidget')]//label")
	WebElement depatureDate;
	
	@FindBy(id = "username")
	WebElement userName;
	
	@FindBy(id = "password")
	WebElement passWord;
	
	@FindBy(xpath="//*[@data-cy='login']")
	WebElement loginButton;
	
	@FindBy(xpath="//div[contains(@class,'btnContainer appendBottom25')]")
	WebElement continueButton;
	
	
	public void getCityList(String city, WebDriver driver) {
		List<WebElement> options = driver.findElements(By.xpath("//ul[@class = 'react-autosuggest__suggestions-list']/li/div/div/p"));
		for(WebElement option: options) {
			if(option.getText().startsWith(city)) {
				JavascriptExecutor exe = (JavascriptExecutor)driver;
				exe.executeScript("arguments[0].click();", option);
				//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				//option.click();
				break;
			}
			
		}
	}
	
	public void handleDate(String date, String month, WebDriver driver) {
		while(!driver.findElement(By.cssSelector(".DayPicker-Caption")).getText().contains(month)) {
			System.out.println(driver.findElement(By.cssSelector(".DayPicker-Caption")).getText());
			driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
			}
		
		List<WebElement> dates = driver.findElements(By.cssSelector(".DayPicker-Day"));
		for(WebElement date1: dates) {
			if(date1.getText().startsWith(date)) {
				
				date1.click();
				break;
			}
		}
	}
	
	public void gettravellersAndClass() {
		WebElement option = driver.findElement(By.cssSelector("div[data-cy='flightTraveller'] [class='lbl_input latoBold appendBottom10']"));
		JavascriptExecutor exe = (JavascriptExecutor)driver;
		exe.executeScript("arguments[0].click();", option);
		
	}
	
	public void selectTravellersAndClass(String adults, WebDriver driver) {
		driver.findElement(By.xpath("//div[@class='travellers']/div[@class='appendBottom20']/ul[1]/li["+adults+"]")).click();
		
	} 
	

}
