package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.PageFactory;


import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.MMTHomePage;
import resourses.Utilities;
import resourses.Utilities;

public class StepDefinition extends Utilities{

	
	@Given("^Open the browser and start application$")
	public void open_the_browser_and_start_application() throws Throwable {
		driver = initializeDriver();
		
	    
	}
	
	@When("^I enter username and password$")
	public void i_enter_username_and_password(DataTable dt) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		MMTHomePage homePage = PageFactory.initElements(driver, MMTHomePage.class);
		List<String> list = dt.asList(String.class);
		homePage.loginLink().click();
		homePage.getUsername().sendKeys(list.get(0));
		homePage.getContinue().click();
		System.out.println(list.get(1));
		homePage.getPassword().sendKeys(list.get(1));
	   
	}

	@When("^click on login$")
	public void click_on_login() {
		MMTHomePage homePage = PageFactory.initElements(driver, MMTHomePage.class);
		homePage.getLogin().click();
	    
	}


	@When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" Travellers and Class$")
	public void i_enter_From_To_Depature_date_Travellers_and_Class_and_click_on_Search(String frmCity, String toCity, String date, String month) throws Throwable {

		MMTHomePage homePage = PageFactory.initElements(driver, MMTHomePage.class);
		
		//Get from city
		homePage.getFromCity().sendKeys(frmCity);
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    homePage.getCityList(frmCity, driver);
	    //Get to City
	    homePage.getToCity().sendKeys(toCity);
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    homePage.getCityList(toCity, driver);
	    //Get Depature date
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   // homePage.getDepatureDate().click();
	    //homePage.getDepatureDate().click();
	    homePage.handleDate(date, month, driver);
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    homePage.gettravellersAndClass();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    homePage.selectTravellersAndClass("3", driver);   
	    driver.manage().deleteAllCookies();
	}

	@When("^click on search$")
	public void click_on_search() {
	    
	    
	}
	
	@Then("^List of flights should be displayed$")
	public void list_of_flights_should_be_displayed(){
	   
	}

}
